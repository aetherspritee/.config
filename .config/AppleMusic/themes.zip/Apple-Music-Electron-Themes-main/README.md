# Apple-Music-Electron-Themes
Simple theme repository for use with https://github.com/Apple-Music-Electron/Apple-Music-Electron

## [Instructions](https://github.com/Apple-Music-Electron/Apple-Music-Electron/wiki/Theme-Creation#instructions)

## [Theme Preview Images](https://github.com/Apple-Music-Electron/Apple-Music-Electron/wiki/Theme-Preview-Images)